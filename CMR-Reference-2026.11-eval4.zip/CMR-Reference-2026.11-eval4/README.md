# CMR Reference 2026.11-eval4

Start with docs/COLLEAGUE_INTRO.md. Release notes: docs/RELEASE_NOTES_2026.11-eval4.md. Feedback: docs/FEEDBACK_TEMPLATE.md.
Run locally: cd app && python -m http.server 8080, then open http://localhost:8080.
Deploy/rollback: docs/RELEASE_CHECKLIST.md. Verification: docs/VALIDATION.md.
