CMR Reference PWA

Files:
- index.html: app
- manifest.webmanifest: install metadata
- service-worker.js: offline cache
- icons/: install icons

To install on iPhone/iPad:
1. Host this folder on an HTTPS website.
2. Open the site in Safari.
3. Tap Share > Add to Home Screen.

To install on Android/Chrome:
1. Host this folder on an HTTPS website.
2. Open the site in Chrome.
3. Choose Install app / Add to Home screen.

Important: service workers do not work reliably from a local file:// URL. The PWA must be served over HTTPS (localhost is also allowed for development).
